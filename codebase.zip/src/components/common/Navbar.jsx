import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

const navLinks = ["about", "skills", "projects", "github", "experience", "contact"];

function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("");
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);

      const sections = navLinks.map((id) => document.getElementById(id));

      sections.forEach((section) => {
        if (!section) return;

        const top = section.offsetTop - 120;
        const height = section.offsetHeight;

        if (window.scrollY >= top && window.scrollY < top + height) {
          setActive(section.id);
        }
      });
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 z-[999] w-full transition-all duration-300 ${
          scrolled
            ? "border-b theme-border bg-slate-950/70 backdrop-blur-xl"
            : "bg-transparent"
        }`}
      >
        <div className="container-width flex items-center justify-between px-6 py-5">
          {/* Logo */}
          <a href="#" className="text-2xl font-bold theme-heading">
            Meet Vora
          </a>

          {/* Desktop Nav */}
          <nav className="hidden items-center gap-8 md:flex">
            {navLinks.map((link) => (
              <a
                key={link}
                href={`#${link}`}
                className={`text-sm font-medium uppercase tracking-[0.15em] transition ${
                  active === link
                    ? "text-violet-400"
                    : "text-gray-300 hover:theme-heading"
                }`}
              >
                {link}
              </a>
            ))}
          </nav>

          <button
            onClick={toggleTheme}
            className="hidden rounded-2xl border theme-border theme-glass p-3 theme-heading transition hover:bg-white/10 md:block"
          >
            {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {/* Mobile Button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="theme-heading md:hidden"
          >
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="border-t theme-border bg-slate-950/95 backdrop-blur-xl md:hidden"
          >
            <nav className="flex flex-col px-6 py-6">
              {navLinks.map((link) => (
                <a
                  key={link}
                  href={`#${link}`}
                  onClick={() => setMenuOpen(false)}
                  className={`border-b border-white/5 py-4 text-sm uppercase tracking-[0.15em] transition ${
                    active === link ? "text-violet-400" : "text-gray-300"
                  }`}
                >
                  {link}
                </a>
              ))}
            </nav>
            <button
              onClick={toggleTheme}
              className="mt-5 rounded-2xl border theme-border theme-glass px-5 py-3 theme-heading"
            >
              {theme === "dark" ? "Light Mode" : "Dark Mode"}
            </button>
          </motion.div>
        )}
      </header>
    </>
  );
}

export default Navbar;
