import { motion } from "framer-motion";
import Reveal from "../common/Reveal";

const experiences = [
  {
    role: "Full Stack Developer Intern",
    company: "Paperboat Tech Solutions",
    duration: "Jan 2024 — Apr 2024",
    description:
      "Worked on scalable full-stack applications using React.js, Node.js, Express.js, and MongoDB while developing responsive user interfaces and REST APIs.",
  },
  {
    role: "React.js Developer Intern",
    company: "TatvaSoft",
    duration: "Jul 2023 — Aug 2023",
    description:
      "Built responsive frontend components and gained practical experience with modern web development workflows, UI design, and backend integration.",
  },
];

function Experience() {
  return (
    <section
      id="experience"
      className="relative overflow-hidden px-6 py-25"
    >

      {/* Glow */}
      <div className="absolute right-0 bottom-0 h-[300px] w-[300px] bg-violet-600/10 blur-3xl" />

      <div className="container-width relative z-10">

        {/* Heading */}
        <Reveal>
          <div className="mb-20 text-center">

            <p className="mb-4 text-sm uppercase tracking-[0.3em] text-cyan-400">
              Experience
            </p>

            <h2 className="text-4xl font-bold theme-heading md:text-6xl">
              Internship
              <span className="bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent">
                {" "}Journey
              </span>
            </h2>

          </div>
        </Reveal>

        {/* Timeline */}
        <div className="relative mx-auto max-w-4xl">

          {/* Center Line */}
          <div className="absolute left-4 top-0 h-full w-[2px] bg-white/10 md:left-1/2 md:-translate-x-1/2" />

          <div className="space-y-16">

            {experiences.map((item, index) => (
              <Reveal key={index}>

                <div
                  className={`relative flex flex-col md:flex-row ${
                    index % 2 === 0
                      ? "md:flex-row-reverse"
                      : ""
                  }`}
                >

                  {/* Dot */}
                  <div className="absolute left-4 top-8 z-20 h-5 w-5 rounded-full bg-violet-500 shadow-[0_0_20px_rgba(139,92,246,0.8)] md:left-1/2 md:-translate-x-1/2" />

                  {/* Card */}
                  <motion.div
                    whileHover={{ y: -6 }}
                    className="ml-14 w-full rounded-[32px] border theme-border theme-glass p-8 md:ml-0 md:w-[45%]"
                  >

                    <p className="text-sm uppercase tracking-[0.2em] text-violet-400">
                      {item.duration}
                    </p>

                    <h3 className="mt-4 text-3xl font-bold theme-heading">
                      {item.role}
                    </h3>

                    <h4 className="mt-2 text-lg text-cyan-400">
                      {item.company}
                    </h4>

                    <p className="mt-6 leading-relaxed theme-subtext">
                      {item.description}
                    </p>

                  </motion.div>

                </div>

              </Reveal>
            ))}

          </div>
        </div>
      </div>
    </section>
  );
}

export default Experience;